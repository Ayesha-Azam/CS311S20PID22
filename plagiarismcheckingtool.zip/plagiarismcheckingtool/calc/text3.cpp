#include <iostream>
using namespace std;

int main()
{
    int i, n;
    cout << "Largest element = " << arr[0];

    return 0;
}
