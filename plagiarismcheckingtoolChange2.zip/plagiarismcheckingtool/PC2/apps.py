from django.apps import AppConfig


class Pc2Config(AppConfig):
    name = 'PC2'
