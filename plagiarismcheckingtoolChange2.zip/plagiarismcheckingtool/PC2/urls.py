from django .urls import path
from . import views
from .import myviews
urlpatterns=[
path("register",views.register,name='register')
]
