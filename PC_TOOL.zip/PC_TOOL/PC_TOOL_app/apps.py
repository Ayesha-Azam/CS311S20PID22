from django.apps import AppConfig


class PcToolAppConfig(AppConfig):
    name = 'PC_TOOL_app'
