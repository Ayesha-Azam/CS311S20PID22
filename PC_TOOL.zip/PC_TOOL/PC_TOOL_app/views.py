from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def hi(request):
    return render(request, 'PC_TOOL_app/cod.html')
