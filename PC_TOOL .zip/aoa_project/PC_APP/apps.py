from django.apps import AppConfig


class PcAppConfig(AppConfig):
    name = 'PC_APP'
